/*
 * @(#)BlockStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A statement wrapping a block. <p/>
 *
 * @author Andy Yu
 * */
public interface BlockStatementT
  extends StatementT
{
  // ----------------------------------------------------------------------
  
  /**
   * Gets the declared code block, null if none.
   *
   * @return The code block associated with this element. Always non-null.
   */
  public BlockT getBlock();


  /**
   * Attempts to set the code block associated with this element.
   */
  public void setBlock( BlockT block );

}
