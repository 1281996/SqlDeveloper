/*
 * @(#)BreakStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A break statement. JLS3 14.15. <p/>
 *
 * @author Andy Yu
 * */
public interface BreakStatementT
  extends SimpleStatementT
{
}
