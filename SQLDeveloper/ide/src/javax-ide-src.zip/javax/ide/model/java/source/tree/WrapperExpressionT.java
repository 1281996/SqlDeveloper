/*
 * @(#)WrapperExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An expression wrapping another one, either with parentheses or
 * brackets.  Notice the difference between a WrapperExpression and a
 * ListExpression.  Wrapper expressions always have a single operand
 * whereas list expressions may have a variable number of operands. <p/>
 *
 * @author Andy Yu
 * */
public interface WrapperExpressionT
  extends ExpressionT
{
}
