/*
 * @(#)DoStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A do statement. JLS3 14.13. <p/>
 *
 * @author Andy Yu
 * */
public interface DoStatementT
  extends ConditionalStatementT
{
}
