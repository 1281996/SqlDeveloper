/*
 * @(#)ImportT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An import declaration. <p/>
 *
 * @author Andy Yu
 * */
public interface ImportT
  extends HasNameT, HasModifiersT
{
  // ----------------------------------------------------------------------

  static final ImportT[] EMPTY_ARRAY = new ImportT[ 0 ];


  // ----------------------------------------------------------------------
}
