/*
 * @(#)ListExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An expression wrapping a list of expressions. Examples are:
 * argument lists, array constants, and bracket dereference
 * lists. <p/>
 *
 * @author Andy Yu
 * */
public interface ListExpressionT
  extends ExpressionT
{
}
